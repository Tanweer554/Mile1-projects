﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace interest_calculator
{
    class RDaccount:IAccount
    {
        double interest_rate;
        double amount;
        public double CalculateInterest()
        {
            Console.WriteLine("Enter the amount:");
            amount=Convert.ToDouble( Console.ReadLine());
            Console.WriteLine("Enter the maturity period in months:");
            int period = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the age:");
            int age = int.Parse(Console.ReadLine());
            if (period == 6)
            {
                if (age < 60)
                {
                    interest_rate = 7.50;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else
                {
                    interest_rate = 8.00;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);

                }
            }
            else if(period == 9)
            {
                if (age < 60)
                {
                    interest_rate = 7.75;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else
                {
                    interest_rate = 8.25;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);

                }
            }
            else if (period == 12)
            {
                if (age < 60)
                {
                    interest_rate = 8.00;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else
                {
                    interest_rate = 8.50;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);

                }
            }
            else if (period == 15)
            {
                if (age < 60)
                {
                    interest_rate = 8.25;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else
                {
                    interest_rate = 8.75;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);

                }
            }
            else if (period == 18)
            {
                if (age < 60)
                {
                    interest_rate = 8.50;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else
                {
                    interest_rate = 9.00;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);

                }
            }
            else if (period == 21)
            {
                if (age < 60)
                {
                    interest_rate = 8.75;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else
                {
                    interest_rate = 9.25;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);

                }
            }
            return 0;

        }
    }
}
