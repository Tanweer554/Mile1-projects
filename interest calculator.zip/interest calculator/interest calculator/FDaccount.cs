﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace interest_calculator
{
    class FDaccount:IAccount
    {
        double interest_rate;
        double amount;
        int no_of_days;
        int age;
        public double CalculateInterest()
        {
            Console.WriteLine("Enter the FD amount:");
            amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter the no of days:");
            no_of_days = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter your age");
            age = int.Parse(Console.ReadLine());
            if (amount < 10000000)
            {
                if (no_of_days >= 7 && no_of_days <= 14)
                {
                    if (age < 60)
                    {
                        interest_rate = 4.50;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}",interest);
                    }
                    else
                    {
                        interest_rate = 5.00;
                        double interest= (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                }
                else if(no_of_days >= 15 && no_of_days <= 29)
                {
                    if (age < 60)
                    {
                        interest_rate = 4.75;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                    else
                    {
                        interest_rate = 5.25;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                }
                else if (no_of_days >= 30 && no_of_days <= 45)
                {
                    if (age < 60)
                    {
                        interest_rate = 5.50;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                    else
                    {
                        interest_rate = 6.00;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                }
                else if (no_of_days >= 46 && no_of_days <= 60)
                {
                    if (age < 60)
                    {
                        interest_rate = 7;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                    else
                    {
                        interest_rate = 7.50;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                }
                else if (no_of_days >= 61 && no_of_days <= 184)
                {
                    if (age < 60)
                    {
                        interest_rate = 7.50;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                    else
                    {
                        interest_rate = 8.00;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                }
                else if (no_of_days >= 185 && no_of_days <= 365)
                {
                    if (age < 60)
                    {
                        interest_rate = 8.00;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                    else
                    {
                        interest_rate = 8.50;
                        double interest = (amount / 100) * interest_rate;
                        Console.WriteLine("Interest is:{0}", interest);
                    }
                }
            }
            else if(amount > 10000000)
            {
                if(no_of_days>=7 && no_of_days <= 14)
                {
                    interest_rate = 6.50;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else if(no_of_days>=15 && no_of_days <= 29)
                {
                    interest_rate = 6.75;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else if (no_of_days >= 30 && no_of_days <= 45)
                {
                    interest_rate = 6.75;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else if (no_of_days >= 46 && no_of_days <= 60)
                {
                    interest_rate = 8;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else if (no_of_days >= 61 && no_of_days <= 184)
                {
                    interest_rate = 8.50;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
                else if (no_of_days >= 185 && no_of_days <= 365)
                {
                    interest_rate = 10.00;
                    double interest = (amount / 100) * interest_rate;
                    Console.WriteLine("Interest is:{0}", interest);
                }
            }
            return 0;
        }
    }
}
