﻿using System;
using System.Collections.Generic;
namespace VoterEntry
{
    public class VoterManagement
    {
        // TODO: Write your code here
        public List<Voter> VoterList { get; set; }

        public VoterManagement()
        {
            //throw new NotImplementedException();
            VoterList = new List<Voter>();
        }

        public string AddVoter(Voter obj)
        {
            //  throw new NotImplementedException();
            string str = null;
            if (obj == null)
            {
                return str;
            }
            else
            {
                if(String.IsNullOrEmpty(obj.FirstName) || String.IsNullOrEmpty(obj.LastName) || String.IsNullOrEmpty(obj.FathersName) || string.IsNullOrEmpty(obj.Gender) || String.IsNullOrEmpty(obj.Address) || String.IsNullOrEmpty(obj.ConstituencyName) || String.IsNullOrEmpty(obj.DateofBirth.ToString()))
                {
                    return str;
                }
                else
                {
                    try
                    {
                        obj.Age = DateTime.Now.Subtract(obj.DateofBirth).Days / 365;
                        if (obj.Age < 18)
                        {
                            throw new VoterEntry.Exceptions.AgeException("Age Shouldn't be less than 18");
                        }
                        else
                        {
                            Utility.VoterUtility objvoter = new Utility.VoterUtility();
                            str = objvoter.GenerateVoterID(obj.FirstName,obj.LastName,obj.DateofBirth);
                            VoterList.Add(obj);
                            return str;
                        }
                    }
                    catch (VoterEntry.Exceptions.AgeException exp)
                    {
                        Console.WriteLine(exp);
                        throw exp;
                    }
                }
            }
        }

        public bool ModifyVoter(Voter obj)
        {
            //throw new NotImplementedException();
            bool b = false;
            if (obj == null)
            {
                return b;
            }
            else
            {
                if (String.IsNullOrEmpty(obj.FirstName) || String.IsNullOrEmpty(obj.LastName) || String.IsNullOrEmpty(obj.FathersName) || string.IsNullOrEmpty(obj.Gender) || String.IsNullOrEmpty(obj.Address) || String.IsNullOrEmpty(obj.ConstituencyName) || String.IsNullOrEmpty(obj.DateofBirth.ToString()))
                {
                    return b;
                }
                else
                {
                    try
                    {
                        obj.Age = DateTime.Now.Subtract(obj.DateofBirth).Days / 365;
                        if (obj.Age < 18)
                        {
                            throw new VoterEntry.Exceptions.AgeException("Age Shouldn't be less than 18");
                        }
                        else
                        {
                            for(int i = 0; i < VoterList.Count; i++)
                            {
                                if (VoterList[i].VoterID == obj.VoterID)
                                {
                                    b = true;
                                }
                            }
                        }
                    }
                    catch(VoterEntry.Exceptions.AgeException exp)
                    {
                        Console.WriteLine(exp);
                        throw exp;
                    }
                }
                return b;
            }
        }

        public Voter SearchVoter(string strVoterID)
        {
            //throw new NotImplementedException();
            Voter v = null;
            for(int i = 0; i < VoterList.Count; i++)
            {
                if (VoterList[i].VoterID == strVoterID)
                {
                    v = VoterList[i];
                }
                else
                {
                    return v;
                }
            }
            return v;
        }

        public bool DeleteVoter(string strVoterID)
        {
            //throw new NotImplementedException();
            bool b = false;
            for(int i = 0; i < VoterList.Count; i++)
            {
                if (VoterList[i].VoterID == strVoterID)
                {
                    VoterList.RemoveAt(i);
                    b = true;
                }
                else
                {
                    return b;
                }
            }
            return b;
        }

        public List<Voter> GetVoterList()
        {
            //throw new NotImplementedException();
            return VoterList;
        }
    }
}
