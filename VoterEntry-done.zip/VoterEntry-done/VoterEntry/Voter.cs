﻿using System;

namespace VoterEntry
{
    public class Voter
    {
        // TODO: Write your code Here
        public string VoterID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FathersName { get; set; }
        public string Gender { get; set; }
        public DateTime DateofBirth { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string ConstituencyName { get; set; }
    }
}
