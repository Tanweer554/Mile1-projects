﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement.Utility
{
    public class EmployeeUtility
    {
        public void GenerateUserName(Employee obj,int EmployeeCount)
        {
            // throw new NotImplementedException();
            string str = ((char)obj.FirstName[0]).ToString() + obj.FirstName.Length.ToString() + ((char)obj.LastName[0]).ToString() + obj.LastName.Length.ToString();
            str += SumDigits(obj.BirthYear) + SumDigits(obj.BirthMonth) + SumDigits(obj.BirthDay);
            str += EmployeeCount.ToString();
            obj.UserID = str;
        }

        public string SumDigits(int value)
        {
            int sum = 0;
            //throw new NotImplementedException();
            while (value > 0)
            {
                sum += value % 10;
                value /= 10;
            }
            return sum.ToString();
        }
    }
}
