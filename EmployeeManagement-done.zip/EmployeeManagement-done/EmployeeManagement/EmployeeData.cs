﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagement
{
    public class EmployeeData
    {
        public List<Employee> EmployeeList { get; set; }
        //TODO : Write your code here.
        public EmployeeData()
        {
            // TODO: Write your code here.
            EmployeeList = new List<Employee>();
        }
        public string AddEmployee(Employee obj)
        {
            // throw new NotImplementedException();
            string str = null;
            if (obj == null)
            {
                return str;
            }
            else
            {
                Utility.EmployeeUtility empobj = new Utility.EmployeeUtility();
                empobj.GenerateUserName(obj, 1);
                EmployeeList.Add(obj);
                return obj.UserID;
               
                
            }
        }

        public bool ModifyEmployee(Employee obj)
        {
            bool b = false;
            //throw new NotImplementedException();
            if (obj == null)
            {
                return b;
            }
            else
            {
                for(int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == obj.UserID)
                    {
                        b = true;
                    }
                    else
                    {
                        b = false;
                    }
                }
                return b;
            }
        }

        public Employee SearchEmployee(string strUserID)
        {
            Employee e = null;
            // throw new NotImplementedException();
            if (String.IsNullOrEmpty(strUserID))
            {
                e = null;
            }
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == strUserID)
                    {
                        e = EmployeeList[i];
                    }
                    else {
                        e = null;
                    }
                }
                
            }
            return e;
        }

        public bool DeleteEmployee(string strUserID)
        {
            // throw new NotImplementedException();
            bool b = false;
            if (String.IsNullOrEmpty(strUserID))
            {
                b = false;
            }
            else
            {
                for (int i = 0; i < EmployeeList.Count; i++)
                {
                    if (EmployeeList[i].UserID == strUserID)
                    {
                        EmployeeList.RemoveAt(i);
                        b = true;
                    }
                    else
                    {
                        b = false;
                    }
                }
               
            }
            return b;
        }
    }
}
